#importing packages
import numpy as numpyModule
import pandas as pandasModule
import matplotlib.pyplot as plotter
from sklearn.model_selection import train_test_split
#Inductive Learning
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,confusion_matrix
#deductive learning
from rulefit import RuleFit

#graphviz
# import graphviz
from sklearn import tree




#loading the dataset
datasetReader=pandasModule.read_csv("OvarianCancer.csv")
print(datasetReader)

#Extracting the relavant features
relavantFeaturesFromKaggale=['HE4', 'NEU', 'CA125', 'ALB', 'Age', 'GLO', 'IBIL', 'HGB', 'PLT', 'Menopause']
#HE4 Human E Virus
#NEU Neutrophyll
#CA125 Cancer Antigen 125
#ALB Albumin
#Age 
#GLO Globulin
#IBIL Indirect Bilurubin
#HGB Haemoglobin
#PLT Platelet

#Extracting suitable features
purifiedDataFromDataSet=datasetReader[relavantFeaturesFromKaggale]

#Preparing dataset for training and testing
X_For_TrainingAndTesting=purifiedDataFromDataSet
print(X_For_TrainingAndTesting)
Y_For_TrainingAndTesting=datasetReader["TYPE"]
X_training,X_testing,Y_training,Y_testing=train_test_split(X_For_TrainingAndTesting,Y_For_TrainingAndTesting,test_size=0.3,random_state=25)

#classifier function

classifierUSingDecisionTreeAlgorithm=DecisionTreeClassifier()
print(classifierUSingDecisionTreeAlgorithm)
#using fit for inductive learning
classifierUSingDecisionTreeAlgorithm.fit(X_training,Y_training)
Y_Predict=classifierUSingDecisionTreeAlgorithm.predict(X_testing)
#the accuracy for inductive learning can be given below
accuracyStorageForInductiveLearning=accuracy_score(Y_testing,Y_Predict)*100
confusion_matrix_inductive=confusion_matrix(Y_testing,Y_Predict)

#classifier function for deductive learning here we are making use of rule fit

classifier_deductive_using_rule_fit_algorithm=RuleFit()
#splitting training and testing
classifier_deductive_using_rule_fit_algorithm.fit(X_training.values,Y_training.values)
Y_pred_deductive=classifier_deductive_using_rule_fit_algorithm.predict(X_testing.values)
#calucating accuracy for deductive learning
accuracy_deductive=accuracy_score(Y_testing,Y_pred_deductive.round())*100
confusion_matrix_deductive = confusion_matrix(Y_testing, Y_pred_deductive.round())

#Graph for inductive and deductive learning can be given as follows

labelsOnGraph=['Negative','Positive']

x_axis_variable=numpyModule.arange(len(labelsOnGraph))
width=0.40

fig,(axisFirst,axisSecond)=plotter.subplots(1,2,figsize=(12,5))
#defining inductive learning graph
axisFirst.bar(x_axis_variable-width/2,confusion_matrix_inductive[:,0],width,label="Predicted Benign Ovarian Tumor")
axisFirst.bar(x_axis_variable+width/2,confusion_matrix_inductive[:,1],width,label="Predicted Ovarian Cancer")
axisFirst.set_ylabel('Counts')
axisFirst.set_title("Confusion matrix for (Inductive Learning)")
axisFirst.set_xticks(x_axis_variable)
axisFirst.set_xticklabels(labelsOnGraph)
axisFirst.legend()
#defining deductive learning learning graph
axisSecond.bar(x_axis_variable-width/2,confusion_matrix_deductive[:,0],width,label="Predicted Benign Ovarian Tumor")
axisSecond.bar(x_axis_variable+width/2,confusion_matrix_deductive[:,1],width,label="Predicted Ovarian Cancer")
axisSecond.set_ylabel("Counts")
axisSecond.set_title("Confusion matrix for (Deductive Learning)")
axisSecond.set_xticks(x_axis_variable)
axisSecond.set_xticklabels(labelsOnGraph)
axisSecond.legend()

fig.tight_layout()
plotter.show()

print("Inductive learning model")
print(accuracyStorageForInductiveLearning)

print("\n Deductive Learning model")
print(accuracy_deductive)


#for visulization of decision tree and Rulefit(Regression)
figure,axis=plotter.subplots(figsize=(30,30))
tree.plot_tree(classifierUSingDecisionTreeAlgorithm,filled=True,fontsize=25,feature_names=X_For_TrainingAndTesting.columns)
#save the figure
plotter.savefig('Image_of_Decision_Tree.png')
plotter.show()

#For rule fit regression
feature_importances_to_be_provided=classifierUSingDecisionTreeAlgorithm.feature_importances_
#Creating dataframe with feature names and their importances
importance_df=pandasModule.DataFrame(
    {"feature":X_For_TrainingAndTesting.columns,"importance":feature_importances_to_be_provided}
)
#Sorting the dataframe based on the importance
importance_df=importance_df.sort_values("importance",ascending=False)
#Plotting feature importances
figure,axis=plotter.subplots(figsize=(30,30))
importance_df.plot(kind="bar",x="feature",y="importance",ax=axis,legend=None,fontsize=30)
plotter.ylabel("Importance which are given",fontsize=40)
plotter.title("Feature importances for RuleFit model",fontsize=40)
plotter.savefig("regression_model_feature_importances.png")
plotter.show()

# #for tableau
# confusion_matrix_data={
#     "Inductive_Learning_Predicted_Benign":confusion_matrix_inductive[:,0],
#     "Inductive_Learning_Predicted_Malignant":confusion_matrix_inductive[:,1],
#     "Deductive_Learning_Predicted_Beningn":confusion_matrix_deductive[:,0],
#     "Deductive_Learning_Predicted_Malignant":confusion_matrix_deductive[:,1]
# }
# confusion_matrix_df=pandasModule.DataFrame(confusion_matrix_data,index=labelsOnGraph)
# confusion_matrix_df.to_csv("Confusion_Matrix_Overall.csv")